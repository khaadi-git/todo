
// Select HTML elements
let taskInput = document.getElementById("textinput");
let addButton = document.getElementById("addButton");
let taskList = document.getElementById("taskList");
let pendingTasks = document.getElementById("pendingtasks");
let clearButton = document.getElementById("clearButton");

// Add Task Function
function addTask() {

    let taskText = taskInput.value.trim();

    if (taskText === "") {
        alert("Please enter a task!");
        return;
    }

    // Create new list item
    let li = document.createElement("li");

    // Create checkbox
    let checkbox = document.createElement("input");
    checkbox.type = "checkbox";

    // Create task text
    let span = document.createElement("span");
    span.innerText = taskText;

    // Mark task as completed
    checkbox.addEventListener("change", function() {
        span.classList.toggle("completed", checkbox.checked);
        updatePendingTasks();
    });

    // Create delete button
    let deleteButton = document.createElement("button");
    deleteButton.innerText = "Delete";

    deleteButton.addEventListener("click", function() {
        li.remove();
        updatePendingTasks();
    });

    // Add elements to list item
    li.appendChild(checkbox);
    li.appendChild(span);
    li.appendChild(deleteButton);

    // Add task to list
    taskList.appendChild(li);

    // Clear input
    taskInput.value = "";

    // Update pending count
    updatePendingTasks();
}

// Update Pending Tasks
function updatePendingTasks() {

    let checkboxes = taskList.querySelectorAll("input[type='checkbox']");

    let pending = 0;

    checkboxes.forEach(function(checkbox) {
        if (!checkbox.checked) {
            pending++;
        }
    });

    pendingTasks.innerText = "Pending Tasks: " + pending;
}

// Clear Completed Tasks
function clearCompleted() {

    let tasks = taskList.querySelectorAll("li");

    tasks.forEach(function(li) {

        let checkbox = li.querySelector("input[type='checkbox']");

        if (checkbox.checked) {
            li.remove();
        }

    });

    updatePendingTasks();
}

// Button Events
addButton.addEventListener("click", addTask);

clearButton.addEventListener("click", clearCompleted);
